#include <stdio.h>

int main () {

  printf("Greetings!\n");

return 0;
}
